package keyllian.dev.com.api_cadastro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCadastroApplicationTests {

	@Test
	void contextLoads() {
	}

}
